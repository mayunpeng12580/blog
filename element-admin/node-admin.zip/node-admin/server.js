const express = require('express');
const app = express();
const bodyParser = require("body-parser");

//使用body-parser中间件
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: false}));


//设置跨域访问
app.all('*', function (req, res, next) {
  res.header('Access-Control-Allow-Origin', req.headers.origin);//获取请求源 这样所有请求就都有访问权限了
  res.header('Access-Control-Allow-Credentials', true);
  res.header('Access-Control-Allow-Headers', 'Content-Type,Content-Length, Authorization, Accept,X-Requested-With')
  res.header('Access-Control-Allow-Methods', 'PUT,POST,GET,DELETE,OPTIONS');
  res.header('Content-Type', 'application/json;charset=utf-8');
  next()
});






//引入user.js
const rules = require("./route/api/rules");
const user = require("./route/api/user");
 
app.get('/', function (req, res) {
   res.send('Hello World');
})


var questions=[{
  data:[1,2,3,4,5,6],
  num:444,
  age:12
},
{
  data:213,
  num:444,
  age:12
},
{
  data:456,
  num:678,
  age:13
}];

//写个接口123
app.get('/123',(req,res) => {
  res.status(200);
  res.json(questions);
})

app.use("/api/user", user);
app.use("/api/rules", rules);


 
const server = app.listen(9000, function () {

  const host = server.address().address;
  const port = server.address().port;
 
  console.log(`应用实例，访问地址为 http:${host}:${port}`);
 
})