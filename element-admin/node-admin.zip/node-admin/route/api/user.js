const connection = require('../../db/index');
const express = require("express");
const router = express.Router();
const app = express();

//设置跨域访问
app.all('*', function (req, res, next) {
  res.header('Access-Control-Allow-Origin', req.headers.origin);//获取请求源 这样所有请求就都有访问权限了
  res.header('Access-Control-Allow-Credentials', true);
  res.header('Access-Control-Allow-Headers', 'Content-Type,Content-Length, Authorization, Accept,X-Requested-With');
  res.header('Access-Control-Allow-Methods', 'PUT,POST,GET,DELETE,OPTIONS');
  res.header('Content-Type', 'application/json;charset=utf-8');
  next()
});

//获取用户列表
router.get('/getUserlist', (req, res) => {
    
    var  sql = 'SELECT * FROM bg_users';

    //查询
    connection.query(sql, (err, result) => {
            if(err){
              console.log('[SELECT ERROR] - ',err.message);
              return  res.status(404).json('没有任何内容');
            }

            res.status(200);
            res.json(result);

    });

    connection.end();

} ) 


//增加用户
router.post('/addUser', (req, res) => {
    
    var  addSql = 'INSERT INTO bg_users(name,url,alexa,country) VALUES(?,?,?,?)';
    var  addSqlParams = req.body;
    //增
    connection.query(addSql,addSqlParams, (err, result) => {
            if(err){
            console.log('[INSERT ERROR] - ',err.message);
            return res.status(404).json('添加失败');;
            }        
            res.status(200);
          res.json(result);
    });
    
    connection.end();

} ) 


//编辑用户信息
router.post("/editUser/:id", (req, res) => {

  var modSql = 'UPDATE bg_users SET id = ? name = ? password = ? age = ? grender = ? avr = ?,uid = ? WHERE id = ' + req.params.id;
  var modSqlParams = {};
  if (req.body.id) modSqlParams['id'] = req.body.id;
  if (req.body.name) modSqlParams['name'] = req.body.name;
  if (req.body.password) modSqlParams['password'] = req.body.password;
  if (req.body.age) modSqlParams['age'] = req.body.age;
  if (req.body.grender) modSqlParams['grender'] = req.body.grender;
  if (req.body.avr) modSqlParams['avr'] = req.body.avr;
  if (req.body.uid) modSqlParams['uid'] = req.body.uid;

  //改
  connection.query(modSql,modSqlParams,function (err, result) {
    if(err){
          return res.status(404).json('添加失败');;;
    }        
    res.status(200);
    res.json(result);
  });
  
  connection.end();
 
})

//删除用户
router.get("/deleteUser/:id", (req, res) => {
  var delSql = 'DELETE FROM bg_users where id=' + req.params.id;
  //删
  connection.query(delSql,function (err, result) {
          if(err){
            console.log('[DELETE ERROR] - ',err.message);
            return res.status(404).json('删除失败');
          }        
          res.status(200);
        res.json(result.affectedRows);
  });
  
  connection.end();
})




module.exports = router;
